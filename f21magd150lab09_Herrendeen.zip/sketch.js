//defining key variables 
let capture;
var mic;
var song;
var button;

//Preloading the music
function preload(){
  song = loadSound("Song.mp3");
}
function setup(){
  //Calling the music to play at .5 volume and 1.4x normal speed.
  song.play();
  song.setVolume(0.5);
  song.rate(1.4);
  
  //Adding microphone input
  mic = new p5.AudioIn();
  mic.start();
  
  //Creating the canvas.
  createCanvas(400,400);
  
  //Adding camera input.
  capture = createCapture(VIDEO);
  capture.size(200,200);
  capture.hide();
  //Adding button to stop and start music.
  button = createButton('pause');
  button.mousePressed(togglePlaying);
}
//Creating a function for the button to play and pause the music.
function togglePlaying(){
  if (!song.isPlaying()){
    song.play();
    button.html("pause");
  } else{
    song.pause();
    button.html("play")
}
}
function draw(){
  background('grey');
  //Adding the microphone level into the console in order to see that it is working.
  var vol = mic.getLevel();
  console.log(vol);
  //adding the frame to the "Mirror".
  rect(50,50,300,300);  
  fill('gold');
 // Calling the image to display on the screen.
  image(capture,100,100,200,200); 
}
 