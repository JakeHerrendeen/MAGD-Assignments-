
var ball ={
y:200,
x:300,
xspeed: 4,
yspeed: -3
}
let angle =0;
function setup() {
  createCanvas(600, 400);
  angleMode(DEGREES);
}

function draw() {
  background(255,255,0)
  // Calling the move function. This tells the sketch to use what is in the function below to make the ellipse move.
  move();
  // Calling the Bounce function. This uses the definition of the function to bounce the ball off the walls. I does this by looking at the X and Y values of the ellispe.
 bounce();

  
fill("red")
rect(0,320,4600,60)
  
//Drawing the ellipse on the canvas
 ellipse(ball.x,ball.y,24,24)
 // Move function definition
  function move(){
  ball.x = ball.x + ball.xspeed;
  ball.y = ball.y + ball.yspeed;
  }
  //Bounce Function definition
  function bounce(){
  if (ball.x > width || ball.x < 0){
  ball.xspeed = ball.xspeed * -1;}
  if (ball.y > 300 || ball.y < 0){
  ball.yspeed = ball.yspeed * -1
}
  }
push();
translate(300,100);
rectMode(CENTER);
rotate(angle);
rect(0,0,50,100);
angle = angle + 1;
pop();

push();
translate(150,100);
rectMode(CENTER);
rotate(angle);
rect(0,0,50,100);
angle = angle + 1
pop();
  
push();
translate(450,100);
rectMode(CENTER);
rotate (angle);
rect(0,0,50,100);
angle = angle + 1
pop();

//Using mouseX and mouseY makes the shope follow the location of the mouse.
fill("blue")
rect(mouseX,mouseY, 20, 40);

  
  
  
  
  
}