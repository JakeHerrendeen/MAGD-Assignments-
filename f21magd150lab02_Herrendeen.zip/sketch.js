function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
fill('red')
triangle(50,50,350,50,200,350);

push();
line(200,350,200,50);
strokeWeight(6);
stroke('white')
  
fill('green')
bezier(208,350,98,305,210,210,340,70);

push();
fill('blue')
arc(0,0,120,120,0,HALF_PI);
arc(0,300,360,360,0,HALF_PI)
pop();


fill('Pink')
beginShape();
vertex(150,200);
vertex(175,350);
vertex(125,200);
vertex(350,250);
vertex(200,100);
vertex(75,50);
endShape()
  
  
  
colorMode(RGB,200)
}