// defining variables
  let leaves = []; 
  var trees =[];

  function setup() {
  createCanvas(710, 400);
  background(100, 89, 100);
  
//Calling Class
  for (let i = 0; i < 25; i++) {
  leaves.push(new Falling());
  }
  
//Making trees using an arrey
  for (var y = 0; y<width; y++){
  trees[y] = random(10000);
  }}

  function draw() {
  
//Drawing the Array
  for (var y=0; y< trees.length; y++){
  stroke(trees[y]);
  line(y,0,y,height);
  }  
  
//Drawing the Leaves
  for (let i = 0; i < leaves.length; i++) {
  leaves[i].move();
  leaves[i].display();
  }
  
//Adding tree tops with a loop 
  fill("orange") 
  rect(0,0,710,50);
  for (var x=0; x<=width; x +=50) {
  fill("orange");
  ellipse(x, 45,50,50);
  strokeWeight(2);
}}

//defining class
//First, What the size and color of the Leaves
  class Falling {
  constructor() {
  this.x = random(width);
  this.y = random(height);
  this.diameter = random(10, 30);
  this.speed = 5;
  this.c = color(random(140), random(110), random(30));  
  }

//Setting the leaves to drop at a random speed in a downward motion with a horizontal random motion.    
  move() {
  this.x += random(-this.speed, this.speed);
  this.y +=(-this.speed, this.speed);

//Once the leave fall through the window, we set them to "respawn" in a differant random location
  if (this.y > height) {
  this.y = random(10);
  }}

//Applying the color and shape to the leaves
  display() {
  fill(this.c);
  ellipse(this.x, this.y, this.diameter, this.diameter);
  }}