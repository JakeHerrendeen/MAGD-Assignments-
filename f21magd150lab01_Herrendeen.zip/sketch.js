function setup() {
  createCanvas(200,200);
}
function draw() {
  background(199);
rect(20,70,160,100);
fill('white')
rect(40,60,120,60)
ellipse(40,60,30,30)
ellipse(160,60,30,30)
ellipse(120,140,10,10)
ellipse(80,140,10,10)
ellipse(120,160,10,10)
ellipse(80,160,10,10)
fill(100);
point(40,60);
point(160,120);
stroke('black');
point(40,120);
point(160,60);
line(120,60,160,80);
line(80,60,160,100);
line(40,60,160,120);
line(40,80,120,120);
line(40,100,80,120);
point(100,0);
line(100,0,40,60);
line(100,0,160,60);
strokeWeight(5);
  
}